package com.example.will.scheduler;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.SSLSocketFactory;

public class NextActivity extends AppCompatActivity {
    private ArrayList<String> ingredientsList = new ArrayList<String>();
    private ArrayList<String> recipesList;
    private String[] idek;
    private String[] myIngredients;
    private TextView mDisplayTitle;
    private TextView mDisplayRecipe;
    private Button mBack;
    private int currentItem;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
        ingredientsList = getIntent().getStringArrayListExtra("INGREDIENTS_LIST");
        recipesList = getIntent().getStringArrayListExtra("MY_RECIPES");
        myIngredients = getIntent().getStringArrayExtra("MY_INGREDIENTS");
        currentItem = getIntent().getIntExtra("CURRENT_ITEM", 0);
        mDisplayRecipe = (TextView)findViewById(R.id.display_recipe);
        idek = getIntent().getStringArrayExtra("RECIPES_LIST");
        mBack = (Button)findViewById(R.id.back8);
        String[] temp = recipesList.get(currentItem).split("Ingredients:|Recipe:");
        String display = "";
        display += temp[0] + "\r\n" + temp[1] + "\r\n";
        String[] blah = temp[2].split("\\. ");
        for(int i = 0; i < blah.length; i++){
            display += (i+1) + ". " + blah[i] + "\r\n";
        }
        mDisplayRecipe.setText(display);
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NextActivity.this, RecipeActivity.class);
                i.putExtra("INGREDIENTS_LIST", ingredientsList);
                i.putExtra("RECIPES_LIST", idek);
                i.putExtra("MY_INGREDIENTS", myIngredients);

                startActivity(i);
            }
        });
//        HttpResponse response = null;
//        try {
//            HttpClient client = new DefaultHttpClient();
//            HttpGet request = new HttpGet();
//            request.setURI(new URI("https://www.wikipedia.org"));
//            response = client.execute(request);
//        } catch (URISyntaxException e) {
//            e.printStackTrace();
//        } catch (ClientProtocolException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        HttpEntity temp =  response.getEntity();
//        InputStream test = null;
//        String testString = "";
//        try{
//            test = temp.getContent();
//            int size = test.available();
//            byte[] blah = new byte[size];
//            test.read(blah);
//            testString = new String(blah);
//            test.close();
//        }catch (IOException e){
//            e.printStackTrace();
//        };
//        String testString = "";
//        URL url = null;
//        try {
//            url = new URL("http://stackoverflow.com");
//
//            try (BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"))) {
//                for (String line; (line = reader.readLine()) != null; ) {
//                    testString += line;
//                }
//            }catch (IOException e){
//                e.printStackTrace();
//            }
//        }catch (MalformedURLException e){
//            e.printStackTrace();
//        };
    }
}
