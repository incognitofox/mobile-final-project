package com.example.will.scheduler;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText mIngredientsInput;
    private EditText mRestrictionsInput;
    private Button mButton;
    private String[] mIngredients;
    private String recipes;
    private String[] recipes_list;
    private ArrayList<String> ingredients_list;
    private ArrayList<String> mRecipes = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mIngredientsInput = (EditText)(findViewById(R.id.available_ingredients));
        mRestrictionsInput = (EditText)findViewById(R.id.restrictions);
        mButton = (Button)(findViewById(R.id.enter_ingredients));
        try {
            String filename = "recipes.txt";
            InputStream infile = getAssets().open(filename);
            int size = infile.available();
            byte[] temp = new byte[size];
            infile.read(temp);
            recipes = new String(temp);
            infile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        recipes_list = recipes.split("@");
        ingredients_list = new ArrayList<String>();
        for(int i = 0; i < recipes_list.length; i++){
            String[] temp = recipes_list[i].split("Ingredients:|Recipe:");
            ingredients_list.add(temp[1]);
            mRecipes.add(temp[2]);

        }
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = mIngredientsInput.getText().toString();
                mIngredients = s.split(", ");
                String t = mRestrictionsInput.getText().toString();
                String[] myRestrictions = t.split(", ");
                if(t.isEmpty())
                    myRestrictions[0] = "none";
                Intent i = new Intent(MainActivity.this, RecipeActivity.class);
                i.putExtra("INGREDIENTS_LIST", ingredients_list);
                i.putExtra("MY_INGREDIENTS", mIngredients);
                i.putExtra("RECIPES_LIST", recipes_list);
                i.putExtra("MY_RESTRICTIONS", myRestrictions);
                i.putExtra("MY_RECIPES", mRecipes);
                startActivity(i);
            }
        });


    }
}
