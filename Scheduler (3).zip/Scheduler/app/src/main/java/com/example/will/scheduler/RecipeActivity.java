package com.example.will.scheduler;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class RecipeActivity extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener{
    String[] myIngredients;
    ArrayList<String> ingredientsList;
    String[] recipesList;
    ArrayList<String> plausableRecipes = new ArrayList<String>();
    MyRecyclerViewAdapter adapter;
    String currentItem;
    ArrayList<String> blah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        RecyclerView recyclerView = (RecyclerView)(findViewById(R.id.playedQuestions));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, plausableRecipes);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
        myIngredients = getIntent().getStringArrayExtra("MY_INGREDIENTS");
        ingredientsList = getIntent().getStringArrayListExtra("INGREDIENTS_LIST");
        recipesList = getIntent().getStringArrayExtra("RECIPES_LIST");
        blah = new ArrayList<String>();
        String[] myRestrictions = getIntent().getStringArrayExtra("MY_RESTRICTIONS");
        Button restart = (Button)findViewById(R.id.restart2);
        for(int i = 0; i < ingredientsList.size(); i++){
            String a = ingredientsList.get(i);
            int count = 0;
            for(int j = 0; j < myIngredients.length; j++){
                String b = myIngredients[j];
                if(a.contains(b)){
                    count++;
                }
            }

            boolean okay = true;
            for(int j = 0; j < myRestrictions.length; j++){
                if(myRestrictions[0] != "none" && myRestrictions.length > 0 && a.contains(myRestrictions[j]))
                    okay = false;
                if(myRestrictions.length == 0){
                    okay = true;
                }
            }
            if(count >= myIngredients.length*0.7 && okay){
                plausableRecipes.add(recipesList[i].substring(0, recipesList[i].indexOf("Ingredients:")-2));
                blah.add(recipesList[i]);
            }
        }

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(RecipeActivity.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
    @Override
    public void onItemClick(View view, int position) {
        Intent i = new Intent(this, NextActivity.class);
        i.putExtra("MY_INGREDIENTS", myIngredients);
        i.putExtra("INGREDIENTS_LIST", ingredientsList);
        i.putExtra("RECIPES_LIST", recipesList);
        i.putExtra("MY_RECIPES", blah);
        i.putExtra("CURRENT_ITEM", position);
        startActivity(i);

    }

}
